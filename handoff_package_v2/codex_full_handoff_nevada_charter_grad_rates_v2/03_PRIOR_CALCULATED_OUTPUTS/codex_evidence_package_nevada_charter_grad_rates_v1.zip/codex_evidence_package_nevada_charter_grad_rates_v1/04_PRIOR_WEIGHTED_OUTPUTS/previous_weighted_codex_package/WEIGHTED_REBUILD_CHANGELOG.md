# Weighted Rebuild Change Log

## Largest changes from prior unweighted campus averages

| class_year   | series_label                          |   current_unweighted_panel_avg |   weighted_rate_from_counts |   weighted_minus_current_avg |   cohort_count_used |   unmatched_rows |
|:-------------|:--------------------------------------|-------------------------------:|----------------------------:|-----------------------------:|--------------------:|-----------------:|
| 2023-24      | SPCSA alternative weighted            |                          75.25 |                       37.76 |                       -37.49 |                 678 |                0 |
| 2022-23      | SPCSA alternative weighted            |                          72.78 |                       36.11 |                       -36.66 |                 504 |                0 |
| 2019-20      | SPCSA alternative weighted            |                          77.05 |                       40.49 |                       -36.56 |                 326 |                0 |
| 2018-19      | SPCSA alternative weighted            |                          76.4  |                       44.88 |                       -31.52 |                 381 |                0 |
| 2021-22      | SPCSA alternative weighted            |                          77.18 |                       49.63 |                       -27.55 |                 405 |                0 |
| 2024-25      | SPCSA alternative weighted            |                          67.38 |                       40.97 |                       -26.41 |                 842 |                0 |
| 2020-21      | SPCSA alternative weighted            |                          73.35 |                       48.47 |                       -24.88 |                 326 |                0 |
| 2019-20      | Washoe alternative/watchlist weighted |                          43.45 |                       67.74 |                        24.29 |                  31 |                1 |
| 2017-18      | SPCSA alternative weighted            |                          74.41 |                       51.03 |                       -23.38 |                 390 |                0 |
| 2019-20      | Washoe-sponsored charter weighted     |                          70.48 |                       91.8  |                        21.33 |                 122 |                1 |
| 2018-19      | Washoe-sponsored charter weighted     |                          68.7  |                       85.94 |                        17.24 |                 128 |                1 |
| 2015-16      | SPCSA alternative weighted            |                          75.05 |                       58.14 |                       -16.91 |                 172 |                0 |
| 2013-14      | SPCSA brick & mortar weighted         |                          67.02 |                       50.94 |                       -16.08 |                 477 |                0 |
| 2013-14      | SPCSA alternative weighted            |                          58.02 |                       43.23 |                       -14.79 |                 643 |                0 |
| 2015-16      | SPCSA charter-only weighted           |                          74.06 |                       60.11 |                       -13.95 |                 910 |                0 |
| 2016-17      | Washoe-sponsored charter weighted     |                          74.1  |                       60.44 |                       -13.66 |                 182 |                1 |
| 2016-17      | SPCSA alternative weighted            |                          68.75 |                       55.76 |                       -12.99 |                 269 |                0 |
| 2016-17      | SPCSA charter-only weighted           |                          70.53 |                       58.18 |                       -12.34 |                1167 |                0 |
| 2018-19      | SPCSA charter-only weighted           |                          89.63 |                       77.65 |                       -11.99 |                1682 |                2 |
| 2017-18      | Washoe-sponsored charter weighted     |                          68.97 |                       80.91 |                        11.94 |                 110 |                1 |

## Interpretation

Large negative deltas usually mean large lower-performing cohorts were underweighted by the average-school method, especially statewide online or alternative programs.

Large positive deltas usually mean larger high-performing cohorts were underweighted by the average-school method, especially some brick-and-mortar high-school operators.

## Immediate public-facing correction

Do not present the older unweighted values as sector graduation rates. Present them only as average campus ACGR if retained.
