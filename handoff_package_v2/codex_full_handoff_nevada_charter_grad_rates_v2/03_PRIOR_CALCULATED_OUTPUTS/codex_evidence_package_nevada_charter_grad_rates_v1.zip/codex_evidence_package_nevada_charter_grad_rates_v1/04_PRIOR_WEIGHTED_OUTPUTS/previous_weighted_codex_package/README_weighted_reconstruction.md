# Nevada Charter Graduation Rates — Weighted Reconstruction Draft

This package is a Codex-ready replacement draft for the existing Nevada charter graduation-rate repository.

## Why this update exists

The prior publishable trend table treated many estimated charter-sector breakouts as unweighted campus averages. That answered a limited question: what was the average reported school-level ACGR among counted campuses? It did **not** answer the student-weighted ACGR question used by Nevada's official graduation-rate reporting.

The revised primary calculation is:

```text
Weighted ACGR = sum(total graduates) / sum(total cohort students) * 100
```

This moves the project from an average-campus statistic to a student-weighted sector statistic.

## Main methodological changes

1. **Headline charter-sector series should use weighted numerator/denominator math.**
   - Replace school-rate averages with summed graduates divided by summed cohorts wherever counts are available.
   - Keep unweighted campus averages only as a secondary diagnostic series, clearly labeled as `average_school_acgr` or similar.

2. **Sector division remains legally and analytically defensible.**
   - First determine whether the school was legally operating as a Nevada charter school for the reporting year.
   - Then classify counted charter rows by model: brick & mortar, statewide virtual, alternative/APF-aligned, Beacon separate if desired.
   - District-run choice programs, district virtual schools, magnets, and contract schools are excluded unless they were charter schools under Nevada charter law for that year.

3. **Early-year interpretation should focus on composition.**
   - In the early years, the high-school charter universe was small and heavily affected by large statewide online schools and alternative schools.
   - High-performing brick-and-mortar operators such as Coral and Nevada State High School existed, but they were much smaller than the online operators.
   - Many later high-performing K-8 operators had not yet opened high-school grades, so early graduation-rate results should not be read as representative of the entire charter sector.

4. **Grade-12 enrollment files should be used as universe-validation evidence, not as ACGR denominators.**
   - Validation-day grade-level enrollment can help determine whether a school had reached grade 12.
   - ACGR denominators should come from the cohort graduation-rate files, not grade-12 enrollment.

## Files in this draft package

- `nevada_charter_weighted_sector_series_long.csv` — replacement long table with weighted rates, cohorts, graduates, deltas, and data-quality flags.
- `nevada_charter_weighted_sector_trend_table.csv` — replacement wide trend table of weighted rates only.
- `nevada_charter_weighted_sector_counts_wide.csv` — wide cohort and graduate counts by series.
- `nevada_charter_weighted_vs_unweighted_delta.csv` — audit table comparing old unweighted averages to weighted rates.
- `nevada_charter_unmatched_rows_for_codex_review.csv` — rows/series requiring name-code matching, suppression, or universe review.
- `nevada_charter_weighted_line_items_audit.csv` — school-level matched line-item support for the weighted calculations.
- `nevada_report_official_context_rates.csv` — official context rows from Nevada's own export.
- `README_weighted_reconstruction.md` — this file.
- `nevada-charter-graduation-rates-overview-weighted.html` — revised public overview page.
- `nevada-charter-graduation-rates-weighted.html` — revised data page.
- `CODEX_WEIGHTED_REBUILD_INSTRUCTIONS.md` — concrete instructions for Codex to review, patch, and integrate.

## Known caveats

- Some later-year SPCSA brick-and-mortar rows remain unmatched in the draft line-item audit due to name variants, new campuses, or suppressed/tiny cohorts. The 2024-25 unmatched list includes Explore Academy, CASLV Cadence, Southern Nevada Trades High School, CIVICA Academy, Young Women's Leadership Academy of Las Vegas, and NSHS Meadowwood.
- Unmatched rows should not automatically be treated as errors. Several are likely suppressed or not yet in the graduation-rate universe.
- Confidence flags in the draft tables are data-quality flags, not statistical confidence intervals.

## Recommended public language

Use `weighted charter-sector ACGR reconstruction` for the new headline measure.

Use `average campus ACGR` only for the old unweighted measure.

Do not call the old unweighted values `sector graduation rates` without qualification.
