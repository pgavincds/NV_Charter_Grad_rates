# Codex instructions: integrate weighted Nevada charter ACGR methodology

## Goal

Update the existing Nevada charter graduation-rate repository so the primary charter-sector estimates are student-weighted ACGR reconstructions, not unweighted school-rate averages.

## Required code/data changes

1. Replace or supplement `nevada_charter_publishable_trend_table.csv` with `nevada_charter_weighted_sector_trend_table.csv`.
2. Add `nevada_charter_weighted_sector_series_long.csv` as the primary chart-ready source.
3. Preserve the old unweighted values only as `current_unweighted_panel_avg` / `average_school_acgr` diagnostics.
4. Update HTML pages to display:
   - weighted rate
   - cohort count used
   - graduates used
   - data-quality flag
   - unmatched row count where applicable
5. Update chart labels from generic `estimate` language to `weighted ACGR reconstruction`.
6. Add a methodology section explaining:
   - weighted formula: sum graduates / sum cohort
   - grade-12 enrollment as a universe check, not a denominator
   - legal charter-status rule before model classification
   - district-operated choice/virtual/contract schools excluded from charter universe
   - early-year composition issue: small high-performing brick-and-mortar schools vs large online schools
7. Add a Codex review step for unmatched rows in `nevada_charter_unmatched_rows_for_codex_review.csv`.

## Acceptance tests

- No headline charter-sector chart/table should be based on a simple average of school rates unless explicitly labeled `average campus ACGR`.
- Weighted values should equal `graduates_used / cohort_count_used * 100` after rounding.
- Official statewide/district/SPCSA rows should remain labeled as Nevada official values, not reconstructed values.
- District-wide Clark/Washoe official rates must not be used as Clark/Washoe charter totals.
- District-run virtual/choice programs must remain excluded from the charter universe unless legally chartered for that year.

## Suggested files to replace

- Replace or branch `nevada-charter-graduation-rates-overview.html` with `nevada-charter-graduation-rates-overview-weighted.html`.
- Replace or branch `nevada-charter-graduation-rates.html` with `nevada-charter-graduation-rates-weighted.html`.
- Replace `nevada_charter_publishable_trend_table.csv` only after reviewing unmatched-row caveats.
