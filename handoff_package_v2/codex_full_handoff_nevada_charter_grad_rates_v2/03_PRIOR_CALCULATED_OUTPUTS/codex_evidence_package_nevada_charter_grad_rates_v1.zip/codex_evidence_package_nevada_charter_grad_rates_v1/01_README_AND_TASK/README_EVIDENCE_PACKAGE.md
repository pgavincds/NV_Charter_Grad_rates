# Nevada Charter Graduation Rates — Codex Evidence Package v1

Date assembled: 2026-06-06

This package contains the **actual evidence files** and human-vetted findings from the Nevada charter graduation-rate review. Codex should ingest these files directly and should not waste cycles rediscovering the core methodology decisions already made.

## What is in this package

- `02_SOURCE_DATA/ACGR_exports/` — Nevada Report Card cohort 4-year ACGR CSV exports, including the broad statewide/school-level post-2013 export and ICDA-focused exports.
- `02_SOURCE_DATA/Validation_Day_enrollment/` — NDE Validation Day grade-level enrollment workbooks for 2021-22 through 2025-26.
- `03_WORKING_INPUTS/` — current project panel file uploaded by the user.
- `04_PRIOR_WEIGHTED_OUTPUTS/` — prior weighted recalculation/checkpoint outputs generated during review.
- `05_SOURCE_NOTES/source_manifest.csv` — source attribution, access date, file hashes, and notes for every included file.

## Primary instruction to Codex

Use this package as the evidence basis for Phase 1. Generate reproducible scripts and final clean outputs from these sources. Do not silently change state-published values. Do not treat unweighted campus averages as headline sector rates.

## Core methodology decision

Primary sector rates must be weighted ACGR:

```text
weighted_acgr = sum(total_graduates) / sum(total_cohort)
```

Unweighted school averages may be retained only as a supplemental measure.

## Reporting-year convention

Nevada reports ACGR in the subsequent accountability year.

Example:

```text
operating_school_year = 2023-24
accountability_reporting_year = 2024-25
```

Validation Day files validate whether a school served grade 12 in the operating year. ACGR exports report the graduating class in the accountability/reporting year.

## Known vetted findings

### Legal charter status
Include only schools legally operating as Nevada charter schools during the relevant year. Exclude district-operated choice/virtual/contract/alternative schools even if they had open enrollment or third-party vendors.

Known non-charter exclusions:
- Northeastern Nevada Virtual Academy
- NV Learning Academy
- North Star Online
- White Pine/K12-style district-operated virtual programs
- other district-operated alternative, magnet, contract, or choice programs

### YWLA
Exclude through 2024-25 because public board materials and enrollment evidence show no graduating cohort / no grade 12 yet.

Source URL to cite and optionally download/archive:
https://charterschools.nv.gov/uploadedFiles/CharterSchoolsnvgov/content/News/2025/250307-YWLA-Amendment-Reduce-Memo.pdf

### Explore Academy
Validation Day evidence reviewed in this session indicates:
- 2021-22: no grade 12
- 2022-23: no grade 12 / limited to grade 11
- 2023-24: first visible grade 12 count
- 2024-25 and 2025-26: grade 12 present

Therefore first possible ACGR reporting year is 2024-25.

### Quest Academy
Do **not** auto-exclude. Existing project panel shows reported early cohorts:
- 2013-14
- 2014-15
- 2015-16
- 2016-17

Codex must investigate last grade-12 year before excluding later years.

### ICDA
Closure documentation indicates ICDA closed in 2019. The included ICDA ACGR exports show reported cohorts through accountability year 2018-19 / class 2017-18. Include reported cohorts. Do not impute or synthesize post-closure outcomes.

Closure article URL to cite/archive:
https://mynews4.com/news/local/nevadas-oldest-charter-school-to-close-in-june-2019

### State-published conflicts
If Nevada's published ACGR conflicts with graduates/cohort, preserve the state-published ACGR and flag the discrepancy.

Example from review: Quest 2013-14 has published ACGR 80.0 while 26/32 gives 81.25. Use published value for school-level metric; flag in `data_validation_exceptions.csv`.

### Early-sector interpretation
Early Nevada charter high-school outcomes were heavily driven by large statewide virtual and alternative operators. Some high-performing brick-and-mortar schools such as NSHS, Coral, and Quest existed, but were much smaller than the online behemoths. Later trends reflect both performance changes and composition/denominator changes.

## Required final output

Codex should produce a new release package containing:

- weighted sector tables
- graduation universe table
- source manifest
- uncertainty register
- data validation exceptions
- school lifecycle table
- closure cases table
- visualizations
- methodology README
- changelog
- downloadable release ZIP

See `01_README_AND_TASK/CODEX_PHASE1_TASK.md` for the full task.
