# Codex Task: Phase 1 — Implement Weighted Reconstruction from Evidence Package

## Objective

Use the evidence files in this package to build a reproducible Phase 1 rebuild of the Nevada Charter Graduation Rates project.

Do not start by re-researching the methodology. The core decisions are already documented in `README_EVIDENCE_PACKAGE.md`. Your job is to implement them cleanly, generate audit outputs, and produce persuasive initial visualization artifacts.

## Data inputs

Use files in:

```text
02_SOURCE_DATA/ACGR_exports/
02_SOURCE_DATA/Validation_Day_enrollment/
03_WORKING_INPUTS/
04_PRIOR_WEIGHTED_OUTPUTS/
```

The prior weighted outputs are checkpoints, not the final authority. Regenerate final outputs reproducibly from source files wherever possible.

## Required scripts

Create scripts under `scripts/`:

```text
scripts/normalize_acgr_exports.py
scripts/normalize_validation_day_enrollment.py
scripts/build_graduation_universe.py
scripts/build_weighted_sector_series.py
scripts/build_uncertainty_register.py
scripts/build_visualizations.py
scripts/build_release_package.py
```

## Required outputs

Generate clean files under `output/`:

```text
output/source_manifest.csv
output/normalized_acgr_school_year.csv
output/normalized_validation_day_grade_counts.csv
output/graduation_universe.csv
output/weighted_sector_series.csv
output/data_validation_exceptions.csv
output/uncertainty_register.csv
output/closure_cases.csv
output/school_lifecycle_table.csv
output/unmatched_rows.csv
```

## Weighted calculation

For sector aggregates:

```text
weighted_acgr = sum(total_graduates) / sum(total_cohort)
```

Do not headline average-of-school rates.

## Universe rules

A school enters the reconstructed charter graduation universe only when:

1. It was legally a Nevada charter school in that year.
2. It served grade 12 students in the operating year OR has a valid ACGR row.
3. It was operating and attributable for that cohort.

District-operated virtual/choice/contract schools are excluded even when they resemble charters.

## Reporting-year fields

Keep these separate:

```text
operating_school_year
accountability_reporting_year
graduating_class_year
```

Validation Day grade counts map to operating year. ACGR rows map to accountability/reporting year and graduating class.

## State-published conflicts

For each row with total cohort, total graduates, and published graduation rate:

```text
derived_acgr = total_graduates / total_cohort
```

Flag discrepancies > 0.5 percentage points in `data_validation_exceptions.csv`.

If a discrepancy exists, keep the state-published ACGR for school-level official rate fields and document the derived value.

## Known cases to encode

- YWLA: exclude through 2024-25; no graduating cohort yet.
- Explore Academy: exclude before 2023-24 operating year / 2024-25 reporting year.
- Quest Academy: include early reported cohorts; investigate final grade-12 year.
- ICDA: include reported cohorts through final reported year; do not impute post-closure outcomes.
- Northeastern Nevada Virtual Academy: exclude as district-operated virtual program.
- NV Learning Academy / North Star Online / White Pine district virtuals: exclude as district-operated non-charters.

## Visualizations

Use Python + pandas + Plotly. Generate self-contained HTML visualizations and static PNG if feasible.

Required:

1. Weighted ACGR trend: statewide official, SPCSA official, SPCSA charter-only weighted, SPCSA brick-and-mortar weighted, SPCSA virtual weighted, SPCSA alternative weighted.
2. Graduates produced by year: total charter graduates, preferably stacked by model.
3. Cohort size/share by model over time: brick-and-mortar, virtual, alternative.
4. Weighted vs unweighted comparison: explain average student vs average school.
5. Top contributors by selected years: 2013-14, 2018-19, 2024-25.

## Documentation

Create:

```text
output/README_weighted_phase1.md
output/methodology_decisions.md
output/uncertainty_framework.md
output/known_issues_register.md
output/CHANGELOG.md
output/EXECUTIVE_SUMMARY.md
```

Explain:

- why weighted ACGR is primary
- how grade-12 universe validation works
- how legal charter status differs from choice/virtual status
- how closure cases are handled
- how internal state-data conflicts are handled
- why uncertainty is represented as data-quality low/likely/high bands rather than a formal statistical confidence interval
- how early results were shaped by sector composition and large online operators

## Final release package

Create:

```text
release/NV_Charter_Grad_Rates_Weighted_Rebuild_v1.zip
```

It must include:

```text
01_Methodology/
02_Source_Data/
03_Clean_Data/
04_Audit_Files/
05_Visualizations/
06_Public_Website/
07_Change_Log/
EXECUTIVE_SUMMARY.md
release_manifest.csv
```

Stop after Phase 1 and summarize what changed, what remains uncertain, and which rows need human review.
