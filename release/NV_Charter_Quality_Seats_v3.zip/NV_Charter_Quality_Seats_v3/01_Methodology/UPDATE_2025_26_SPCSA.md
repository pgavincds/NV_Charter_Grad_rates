# 2025-26 Rating Update

- Added the user-provided 2025-26 SPCSA NSPF ratings file.
- Appended current-year rating rows for existing SPCSA school-band keys and new SPCSA school-band keys.
- Retained 2024-25 Validation Day enrollment as the carried-forward count-day source, per the current request.
- Twenty rating rows do not have a matching 2024-25 enrollment row and remain in the panel with zero carried-forward seats and explicit audit flags.
- This is a partial 2025-26 update: the current attached rating source covers SPCSA, not district-authorized charter schools. The existing all-charter charts remain on the complete 2024-25 series until those current district files are added.
