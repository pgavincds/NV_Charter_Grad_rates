# CHANGELOG

- Extended charter quality seats series backward to 2015-16 using direct district NSPF downloads.
- Added 2014-15 as an explicit presentation-floor year with no recovered statewide ratings values.
- Fixed the 2015-16 legacy enrollment parser so grade codes like 01/06 join correctly to elementary and middle school bands.
- Added historical seat and share charts with pause-year caveats.
- Confirmed 2013-14 district rating pulls are header-only placeholders, not usable statewide data files.

- Added a partial 2025-26 SPCSA rating update from the user-provided current ratings CSV.
- Carried forward 2024-25 Validation Day enrollment for the new rating year by request; unmatched rows are retained and audited.
- Left the complete all-charter visual series through 2024-25 until current district-authorized charter rating files are available.
